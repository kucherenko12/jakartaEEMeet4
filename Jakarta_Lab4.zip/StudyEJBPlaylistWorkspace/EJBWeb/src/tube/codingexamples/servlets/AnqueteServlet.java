package tube.codingexamples.servlets;

import java.io.IOException;
import java.util.Optional;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import tube.codingexamples.ejb.statelessbean.AnqueteBeanRemote;
import tube.codingexamples.jpa.entity.Anquete;


@WebServlet(urlPatterns = {"/anquete"})
public class AnqueteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@EJB(beanName = "AnqueteBean")
	private AnqueteBeanRemote anqueteMgr;
	
    public AnqueteServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		if(request.getParameter("id") != null)
        {
            Optional<String> idStringOptional = Optional.ofNullable(request.getParameter("id"));
           
            int anqueteId = idStringOptional
            	    .map(Integer::parseInt)   // ������������ String � Integer
            	    .orElse(-1);
            if (anqueteId != -1){
            	 Anquete anquete = anqueteMgr.findAnqueteById(anqueteId);
            
                request.setAttribute("anquete", anquete);
                request.getRequestDispatcher("/WEB-INF/jsp/anquete.jsp").forward(request, response);
            }
            else
            {
                request.getRequestDispatcher("/WEB-INF/jsp/unacceptableanqueteid.jsp").forward(request, response);
            }
        }
        else
        {
            request.getRequestDispatcher("/WEB-INF/jsp/unacceptableanqueteid.jsp").forward(request, response);
        }
	}


}
