package tube.codingexamples.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import tube.codingexamples.ejb.statelessbean.AccountBeanRemote;
import tube.codingexamples.jpa.entity.Account;

/**
 * Servlet implementation class RegisterServlet
 */
@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	
	@EJB(beanName = "AccountBean")
	AccountBeanRemote accountMgr;

	private static final long serialVersionUID = 1L;
       
    public RegisterServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// read form fields
				String username = request.getParameter("username");
				String password = request.getParameter("password");

				// temporary
				response.setContentType("text/html");
				PrintWriter out = response.getWriter();
				out.print(username + " " + password);

				System.out.println("username: " + username);
				System.out.println("password: " + password);
				
				Account account =  accountMgr.newAccount(username, password);
				//Account account = accountMgr.newAccount(username, password);
				if (account!= null) {
					// RequestDispatcher dispatcher =
					// getServletContext().getRequestDispatcher("/forwarded");
					// dispatcher.forward(request, response);

					HttpSession session = request.getSession();
					// session.setAttribute("username", username);
					session.setAttribute("id", String.valueOf(account.getId()));
					session.setAttribute("anqueteId", String.valueOf(account.getAnketa().getId()));
					//out.println("account found: <h2>" + account.getUsername() + "</h2>");
					System.out.println("redirect to anquetesearch");
					
					response.sendRedirect(request.getContextPath() + "/anquetesearch");
					
				} else {
					request.getRequestDispatcher("/WEB-INF/jsp/invalidlogin.jsp").forward(request, response);
				}
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.getRequestDispatcher("/WEB-INF/jsp/register.jsp").forward(request, response);
	}

}
