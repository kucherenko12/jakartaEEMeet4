package tube.codingexamples.servlets;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import tube.codingexamples.ejb.statelessbean.AccountBeanRemote;
import tube.codingexamples.ejb.statelessbean.AnqueteBeanRemote;
import tube.codingexamples.jpa.entity.Anquete;

@WebServlet(urlPatterns = { "/anquetesearch" })
public class AnqueteSearchPageServlet extends HttpServlet {

	@EJB(beanName = "AccountBean")
	private AccountBeanRemote accountMgr;

	@EJB(beanName = "AnqueteBean")
	private AnqueteBeanRemote anqueteMgr;

	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		if (request.getSession().getAttribute("id") != null) {
			
			System.out.println("anquete search page");
			
			Optional<String> tagsStringOptional = Optional.ofNullable(request.getParameter("tags"));
			List<Anquete> anquetes;
			
			if (tagsStringOptional.isPresent() == true && tagsStringOptional.get().equals("")) {
				
				System.out.println("empty keywords");
				
				anquetes = anqueteMgr.getAllAnquetes();
			} else if (tagsStringOptional.isPresent() == true) {
				
				System.out.println("keywords: "+ tagsStringOptional.get());
				
				anquetes = anqueteMgr.findAnqueteByKeywords(tagsStringOptional.get());
			} else {
				anquetes = anqueteMgr.getAllAnquetes();
			}
			request.setAttribute("anquetes", anquetes);
            request.getRequestDispatcher("/WEB-INF/jsp/anquetesearch.jsp").forward(request, response);
		}else{
			request.getRequestDispatcher("/WEB-INF/jsp/notloggedin.jsp").forward(request, response);
		}	
	}

	public AnqueteSearchPageServlet() {
		super();
	}
}
