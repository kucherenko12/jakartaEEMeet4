package tube.codingexamples.servlets;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import tube.codingexamples.ejb.statelessbean.AnqueteBeanRemote;
import tube.codingexamples.jpa.entity.Anquete;
import tube.codingexamples.jpa.entity.Gender;

@WebServlet("/anqueteEditServlet")
public class AnqueteEditPageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@EJB(beanName = "AnqueteBean")
	private AnqueteBeanRemote anqueteMgr;

    public AnqueteEditPageServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		if(request.getSession().getAttribute("id") != null)
        {
			System.out.println("|||||||||||||||anqueteedit Servlet Get");
			
			int accountId = Integer.parseInt((String) request.getSession().getAttribute("id"));
			
			System.out.println("|||||||||||||||accountId "+ accountId);
			
			Anquete anquete = anqueteMgr.findAnqueteByAccountId(accountId);
			
			System.out.println("|||||||||||||||anquete name "+ anquete.getName());
			
            request.setAttribute("anquete", anquete);
            request.getRequestDispatcher("/WEB-INF/jsp/anqueteedit.jsp").forward(request, response);
        }
        else
        {
            request.getRequestDispatcher("/WEB-INF/jsp/notloggedin.jsp").forward(request, response);
        }
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("|||||||||||||||anqueteedit Servlet Post ");
		
		if(request.getSession().getAttribute("id") != null) 
        {
			System.out.println("|||||||||||||||anqueteedit Servlet Post: getAttribute(id) != null ");
            // read form fields
            String idString = (String) request.getSession().getAttribute("anqueteId");          
            
            String name = request.getParameter("name");
            String ageString = request.getParameter("age");
            String shortInfo = request.getParameter("shortInfo");
            String keywords = request.getParameter("keywords");
            String genderString = request.getParameter("gender");
            
            System.out.println("|||||||||||||||anqueteedit Servlet Post request Parameters: " + name + " \n"
            		+ ageString + " \n"
            		+ shortInfo + " \n"
            		+ keywords + " \n"
            		+ genderString);
            
            int anqueteId  = Integer.parseInt(idString);
            int age = Integer.parseInt(ageString);
            int genderId;
            if(genderString.toLowerCase().equals("male")){
            	 genderId = 1;
            } else{
            	genderId = 2;
            }
            Gender gender = new Gender(genderId);
            
            Anquete updatedAnquete = new Anquete(name, age, shortInfo, keywords, gender);
            System.out.println("|||||||||||||||Try to Update anquete with data: "
            + anqueteId
            + updatedAnquete.getName() + " \n"
            + updatedAnquete.getAge() + " \n"
    		+ updatedAnquete.getShortInfo() + " \n"
    		+ updatedAnquete.getKeywords() + " \n"
    		+ updatedAnquete.getGender());
   
            int resultCode = anqueteMgr.editAnquete(anqueteId, updatedAnquete);
            System.out.println("|||||||||||||||Update result code: " + resultCode);	
            response.sendRedirect(request.getContextPath() + "/anquetesearch");
        }
        else
        {
            request.getRequestDispatcher("/WEB-INF/jsp/notloggedin.jsp").forward(request, response);
        }
	}

}
