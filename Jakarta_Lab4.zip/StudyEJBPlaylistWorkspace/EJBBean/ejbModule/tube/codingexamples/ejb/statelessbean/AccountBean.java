package tube.codingexamples.ejb.statelessbean;

import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import tube.codingexamples.jpa.entity.Account;
import tube.codingexamples.jpa.entity.Anquete;

@Stateless(mappedName = "AccountBean")
@LocalBean
public class AccountBean implements AccountBeanRemote {

	@PersistenceContext(unitName="JPADatingSite")
	EntityManager em;
	
    public AccountBean() {
        // TODO Auto-generated constructor stub
    }

	@Override
	public Account newAccount(String username, String password) {
		Anquete anquete = new Anquete();
		anquete.setName(username);
		em.persist(anquete);
		//int userAnqueteId = anquete.getId();
		
		Account account = new Account();
		account.setUsername(username);
		account.setPassword(password);
		account.setAnketa(anquete);
		
		em.persist(account);
		return account;
	}

	@Override
	public Account findAccountById(int accountId) {
		Account account = em.find(Account.class, accountId);
		return account;
	}

	@Override
	public int deleteAccountById(int accountId) {
		Account account = em.find(Account.class, accountId);
		if(account != null){
			em.remove(account);
		}
		return 0;
	}

	@Override
	public Account findAccountByLoginData(String username, String password) {
		String selectAllAccountData = "SELECT a FROM Account a WHERE a.username = :username and a.password = :password";
		TypedQuery<Account> query = em.createQuery(selectAllAccountData, Account.class);
		query.setParameter("username", username);
		query.setParameter("password", password);
		//Account account = query.getSingleResult();
		List<Account> resultList = query.getResultList();
	    if (!resultList.isEmpty()) {
	        return resultList.get(0);
	    } else {
	        return null;
	    }
//		if(account!=null && account.getId() > 0){
//			return account;
//		}else{
//			return null;
//		}
		
	}

}
