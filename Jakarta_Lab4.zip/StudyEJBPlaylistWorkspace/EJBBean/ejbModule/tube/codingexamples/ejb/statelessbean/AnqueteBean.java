package tube.codingexamples.ejb.statelessbean;

import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import tube.codingexamples.jpa.entity.Account;
import tube.codingexamples.jpa.entity.Anquete;
import tube.codingexamples.jpa.entity.Gender;

@Stateless(mappedName = "AnqueteBean")
@LocalBean
public class AnqueteBean implements AnqueteBeanRemote {
	@PersistenceContext(unitName = "JPADatingSite")
	EntityManager em;

	public AnqueteBean() {

	}

	@Override
	public int createNewAnquete(String username) {

		return 0;
	}

	@Override
	public List<Anquete> findAnqueteByKeywords(String keywords) {
		// ��������� ������ ����� �� ����� �����
		String[] keywordsArray = keywords.split(" ");
		// ���������� �����
		StringBuilder queryBuilder = new StringBuilder("SELECT a FROM Anquete a WHERE ");

		// ������ ����� ��� ������� ��������� �����
		for (int i = 0; i < keywordsArray.length; i++) {
			queryBuilder.append("a.keywords LIKE :keyword").append(i);
			if (i < keywordsArray.length - 1) {
				queryBuilder.append(" AND ");
			}
		}
		// ��������� �����
		TypedQuery<Anquete> query = em.createQuery(queryBuilder.toString(), Anquete.class);
		// ������������ ��������� ��� ������� ��������� �����
		for (int i = 0; i < keywordsArray.length; i++) {
			query.setParameter("keyword" + i, "%" + keywordsArray[i] + "%");
		}
		List<Anquete> resultList = query.getResultList();
		if (!resultList.isEmpty()) {
			return resultList;
		} else {
			return null;
		}
	}

	@Override
	public Anquete findAnqueteByAccountId(int accountId) {
		Account account = em.find(Account.class, accountId);
		int anqueteId = account.getAnketa().getId();
		Anquete anquete = em.find(Anquete.class, anqueteId);
		return anquete;
	}


	@Override
	public List<Anquete> getAllAnquetes() {
		String selectAll = "SELECT a FROM Anquete a";
		TypedQuery<Anquete> query = em.createQuery(selectAll, Anquete.class);
		List<Anquete> resultList = query.getResultList();
		if (!resultList.isEmpty()) {
			return resultList;
		} else {
			return null;
		}
	}
	@Transactional
	@Override
	public int editAnquete(int anqueteId, Anquete updatedAnquete) {

	    String jpql = "UPDATE Anquete a SET a.name = :name, a.age = :age, a.shortInfo = :shortInfo, a.keywords = :keywords, a.gender.id = :genderId WHERE a.id = :id";
	    System.out.println("|||||||||||||||SQL QueryString: "+ jpql);
	    System.out.println("|||||||||||||||SQL QueryString anqueteID: "+ anqueteId);
	    
	   // Anquete duplicateAnquete = findAnqueteByName(updatedAnquete.getName());
	    
	    int updatedCount = em.createQuery(jpql)
	            .setParameter("name", updatedAnquete.getName())
	            .setParameter("age", updatedAnquete.getAge())
	            .setParameter("shortInfo", updatedAnquete.getShortInfo())
	            .setParameter("keywords", updatedAnquete.getKeywords())
	            .setParameter("genderId", updatedAnquete.getGender().getId())
	            .setParameter("id", anqueteId)
	            .executeUpdate();
	    
	    if (updatedCount == 0) {
	    	System.out.println("|||||||||||||||Anquete with id " + updatedAnquete.getId() + " not found");
	        throw new IllegalArgumentException("Anquete with id " + updatedAnquete.getId() + " not found");
	    }else{
	    	System.out.println("|||||||||||||||Update success");
	    	return updatedCount;
	    }
	}

	@Override
	public Anquete findAnqueteById(int anqueteId) {
		Anquete anquete = em.find(Anquete.class, anqueteId);
		return anquete;
	}


}
