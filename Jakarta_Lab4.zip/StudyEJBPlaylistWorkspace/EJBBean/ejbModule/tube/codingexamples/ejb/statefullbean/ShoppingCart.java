package tube.codingexamples.ejb.statefullbean;

import java.util.ArrayList;

import javax.ejb.LocalBean;
import javax.ejb.Stateful;


@Stateful(mappedName = "ShoppingCart")
@LocalBean
public class ShoppingCart implements ShoppingCartRemote {

	ArrayList<String> Cart;
	
    public ShoppingCart() {
        Cart = new ArrayList<String>();
    }

	@Override
	public ArrayList<String> listCartItems() {
		return Cart;
	}

	@Override
	public void clearCart() {
		Cart.clear();
		
	}

	@Override
	public void removeProduct(String Name) {
		Cart.remove(Name);
		
	}

	@Override
	public void placeProduct(String Name) {
		Cart.add(Name);
		
	}

}
