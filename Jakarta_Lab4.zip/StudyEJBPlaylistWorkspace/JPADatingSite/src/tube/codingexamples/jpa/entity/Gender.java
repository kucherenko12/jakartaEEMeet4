package tube.codingexamples.jpa.entity;

import java.io.Serializable;
import javax.persistence.*;

@Entity
@Table(name="Gender")
//@NamedQuery(name="Gender.findAll", query="SELECT g FROM Gender g")
public class Gender implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int id;
	@Column(name="name")
	private String genderName;

	public Gender() {
	}
	
	public Gender(int id) {
		this.id = id;
		if(id == 1){
			this.genderName = "male";
		}else{
			this.genderName = "female";
		}
		
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return this.genderName;
	}

	public void setName(String name) {
		this.genderName = name;
	}

}