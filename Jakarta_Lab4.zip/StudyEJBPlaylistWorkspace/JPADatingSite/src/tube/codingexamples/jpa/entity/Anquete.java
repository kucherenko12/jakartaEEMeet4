package tube.codingexamples.jpa.entity;

import java.io.Serializable;


import javax.persistence.*;

@Entity
@Table(name = "Anquete")
public class Anquete implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@Column(name = "name")
	private String name;

	@Column(name = "age")
	private int age;

	@Column(name = "shortInfo")
	private String shortInfo;

	@Column(name = "keyWords")
	private String keywords;
	
	@ManyToOne
    @JoinColumn(name = "gender_id")
	private Gender gender;

	public Anquete() {
		super();
	}
	
	public Anquete(String name, int age, String shortInfo, String keywords, Gender gender) {
		super();
		this.name = name;
		this.age = age;
		this.shortInfo = shortInfo;
		this.keywords = keywords;
		this.gender = gender;
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getShortInfo() {
		return shortInfo;
	}

	public void setShortInfo(String shortInfo) {
		this.shortInfo = shortInfo;
	}

	public String getKeywords() {
		return keywords;
	}

	public void setKeywords(String keywords) {
		this.keywords = keywords;
	}

	public Gender getGender() {
        return gender;
    }

    public void setGender(Gender gender) {
        this.gender = gender;
    }

}
