package tube.codingexamples.ejb.statefullbean;

import java.util.ArrayList;

import javax.ejb.Remote;

@Remote
public interface ShoppingCartRemote {

	ArrayList<String> listCartItems();
	void clearCart();
	void removeProduct(String Name);
	void placeProduct(String Name);
}
