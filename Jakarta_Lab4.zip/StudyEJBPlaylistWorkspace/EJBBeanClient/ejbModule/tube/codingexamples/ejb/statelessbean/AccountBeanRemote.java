package tube.codingexamples.ejb.statelessbean;

import javax.ejb.Remote;

import tube.codingexamples.jpa.entity.Account;

@Remote
public interface AccountBeanRemote {
	public Account newAccount(String username, String password);
	public Account findAccountById(int accountId);
	public Account findAccountByLoginData(String username, String password);
	public int deleteAccountById(int accountId);
	
}
