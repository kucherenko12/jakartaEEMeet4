package tube.codingexamples.ejb.statelessbean;

import java.util.List;

import javax.ejb.Remote;

import tube.codingexamples.jpa.entity.Anquete;

@Remote
public interface AnqueteBeanRemote {
	public int createNewAnquete(String username);
	public Anquete findAnqueteById(int anqueteId);
	public List<Anquete> findAnqueteByKeywords(String keywords);
	public List<Anquete> getAllAnquetes();
	public int editAnquete(int anqueteId, Anquete updatedAnquete);
	public Anquete findAnqueteByAccountId(int accountId);
}
